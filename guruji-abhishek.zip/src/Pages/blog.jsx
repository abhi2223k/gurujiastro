import React from 'react'
import Blog from '../components/Blog'

function blog() {
    return (
        <div>
            <Blog />
        </div>
    )
}

export default blog
