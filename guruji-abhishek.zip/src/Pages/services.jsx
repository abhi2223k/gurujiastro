import React from 'react'
import Ourservices from '../components/Ourservices'
import Whychooseus from '../components/Whychooseus'

function services() {
    return (
        <div>
            <Ourservices />
            <Whychooseus />
        </div>
    )
}

export default services
