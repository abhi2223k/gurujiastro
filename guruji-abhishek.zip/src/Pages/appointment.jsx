import React from 'react'
import Appointment from '../components/Appointment'
import Whychooseus from '../components/Whychooseus'


function appointment() {
    return (
        <div>
            <Appointment/>
            <Whychooseus />
        </div>
    )
}

export default appointment
