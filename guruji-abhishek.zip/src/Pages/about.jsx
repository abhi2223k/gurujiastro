import React from 'react'
import About from '../components/About'
import Whychooseus from '../components/Whychooseus'

function about() {
    return (
        <div>
            <About />
            <Whychooseus />
        </div>
    )
}

export default about
