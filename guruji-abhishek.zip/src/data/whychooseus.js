export const whychooseus = [
  {
    id: 1,
    title: "Qualified Astrologers",
    description: "",
    image: "icons/shape.svg",
  },
  {
    id: 2,
    title: "Qualified Astrologers",
    description: "",
    image: "icons/shape.svg",
  },
  {
    id: 3,
    title: "Qualified Astrologers",
    description: "",
    image: "icons/shape.svg",
  },
  {
    id: 4,
    title: "Qualified Astrologers",
    description: "",
    image: "icons/shape.svg",
  },
  {
    id: 5,
    title: "Qualified Astrologers",
    description: "",
    image: "icons/shape.svg",
  },
  {
    id: 6,
    title: "Qualified Astrologers",
    description: "",
    image: "icons/shape.svg",
  },
];
