export const services = [
  {
    id: 1,
    title: "title1",
    description: "description1",
    image: "icons/service1.svg",
  },
  {
    id: 2,
    title: "title2",
    description: "description1",
    image: "icons/service2.svg",
  },
  {
    id: 3,
    title: "title3",
    description: "description1",
    image: "icons/service3.svg",
  },
  {
    id: 4,
    title: "title4",
    description: "description1",
    image: "icons/service4.svg",
  },
  {
    id: 5,
    title: "title5",
    description: "description1",
    image: "icons/service5.svg",
  },
  {
    id: 5,
    title: "title5",
    description: "description1",
    image: "icons/service5.svg",
  },
  {
    id: 5,
    title: "title5",
    description: "description1",
    image: "icons/service5.svg",
  },
  {
    id: 5,
    title: "title5",
    description: "description1",
    image: "icons/service5.svg",
  },
];
