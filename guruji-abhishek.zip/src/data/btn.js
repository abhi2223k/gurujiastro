export const btn = [
  {
    id: 1,
    title: "prev",
  },
  {
    id: 2,
    title: "next",
  },
];
