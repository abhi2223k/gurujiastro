export const slickbox = [
  {
    id: 1,
    question: "What's Your Sing ?",
    title: "Read Your Daily Horoscope Today",
    description:
      "Consectetur adipiscing elit, sed do eiusmod tempor incididuesdeentiut labore etesde dolore magna aliquapspendisse and the gravida.",
  },
  {
    id: 1,
    question: "What's Your Sing ?",
    title: "Read Your Daily Horoscope Today",
    description:
      "Consectetur adipiscing elit, sed do eiusmod tempor incididuesdeentiut labore etesde dolore magna aliquapspendisse and the gravida.",
  },
  {
    id: 1,
    question: "What's Your Sing ?",
    title: "Read Your Daily Horoscope Today",
    description:
      "Consectetur adipiscing elit, sed do eiusmod tempor incididuesdeentiut labore etesde dolore magna aliquapspendisse and the gravida.",
  },
  {
    id: 1,
    question: "What's Your Sing ?",
    title: "Read Your Daily Horoscope Today",
    description:
      "Consectetur adipiscing elit, sed do eiusmod tempor incididuesdeentiut labore etesde dolore magna aliquapspendisse and the gravida.",
  },
];
