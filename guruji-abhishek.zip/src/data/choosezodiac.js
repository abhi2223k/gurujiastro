export const choosezodiac = [
  {
    id: 1,
    title: "Aries",
    description: "description1",
    image: "icons/service1.svg",
  },
  {
    id: 2,
    title: "Taurus",
    description: "description1",
    image: "icons/service1.svg",
  },
  {
    id: 3,
    title: "Cemini",
    description: "description1",
    image: "icons/service1.svg",
  },
  {
    id: 4,
    title: "Cancer",
    description: "description1",
    image: "icons/service1.svg",
  },
  {
    id: 5,
    title: "Leo",
    description: "description1",
    image: "icons/service1.svg",
  },
  {
    id: 6,
    title: "Virgo",
    description: "description1",
    image: "icons/service1.svg",
  },
  {
    id: 7,
    title: "Libra",
    description: "description1",
    image: "icons/service1.svg",
  },
  {
    id: 8,
    title: "Scorpio",
    description: "description1",
    image: "icons/service1.svg",
  },
  {
    id: 9,
    title: "Sagittarius",
    description: "description1",
    image: "icons/service1.svg",
  },
  {
    id: 10,
    title: "Capricorn",
    description: "description1",
    image: "icons/service1.svg",
  },
  {
    id: 11,
    title: "Capricorn",
    description: "description1",
    image: "icons/service1.svg",
  },
  {
    id: 12,
    title: "Pisces",
    description: "description1",
    image: "icons/service1.svg",
  },
];
