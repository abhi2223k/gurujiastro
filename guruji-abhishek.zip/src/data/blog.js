export const blog = [
  {
    id: 1,
    title: "Consectetur adipiscing elit sedeius mod tempor incididunt ut labore.",
    description: "Consectetur adipiscing elit, sed desdo eiusmod tempor incididuesdeentiut labore etesde doloesire esdesdeges magna aliquapspendisse and the gravida.",
    image: "icons/blog1.jpg",
    imguser: "icons/user.svg",
    imgcomment: "icons/comment.svg",
  },
  {
    id: 2,
    title: "Consectetur adipiscing elit sedeius mod tempor incididunt ut labore.",
    description: "Consectetur adipiscing elit, sed desdo eiusmod tempor incididuesdeentiut labore etesde doloesire esdesdeges magna aliquapspendisse and the gravida.",
    image: "icons/blog2.jpg",
    imguser: "icons/user.svg",
    imgcomment: "icons/comment.svg",
  },
  {
    id: 3,
    title: "Consectetur adipiscing elit sedeius mod tempor incididunt ut labore.",
    description: "Consectetur adipiscing elit, sed desdo eiusmod tempor incididuesdeentiut labore etesde doloesire esdesdeges magna aliquapspendisse and the gravida.",
    image: "icons/blog3.jpg",
    imguser: "icons/user.svg",
    imgcomment: "icons/comment.svg",
  },
];
